import json
from typing import Pattern
import boto3
from datetime import datetime
import pandas as pd
import time
from io import StringIO
import re
import hashlib

from pandas.core.indexes import interval

s3_cient = boto3.client('s3')

def binary_search(list, key, low, high):
  
    mid = int(low + ((high - low) / 2))
    if (list[mid] == key):
        return mid

    if (epoch_time_convertor(key) < epoch_time_convertor(list[mid])): 
        #print("low")
        return binary_search(list, key, low, mid - 1)

    #print("up")
    return binary_search(list, key, mid + 1, high)

def epoch_time_convertor(timestamp):

    utc_time = datetime.strptime(timestamp, "%H:%M:%S.%f")
    epoch_time = (utc_time - datetime(1970, 1, 1)).total_seconds()
    #print(epoch_time)
    return (epoch_time)


def get_closest_index(arr, target):
    n = len(arr)
    left = 0
    right = n - 1
    mid = 0

    # edge case - last or above all
    if target >= epoch_time_convertor(arr[n - 1]):
        return n - 1
    # edge case - first or below all
    if target <= epoch_time_convertor(arr[0]):
        return 0

    # BSearch solution: Time & Space: Log(N)

    while left < right:
        mid = (left + right) // 2  # find the mid
        if target < epoch_time_convertor(arr[mid]):
            right = mid
        elif target > epoch_time_convertor(arr[mid]):
            left = mid + 1
        else:
            return mid

    if target < epoch_time_convertor(arr[mid]):
        if find_closest(epoch_time_convertor(arr[mid - 1]), epoch_time_convertor(arr[mid]), target) == 0:
            return mid - 1
        else:
            return mid
    else:
        if find_closest(epoch_time_convertor(arr[mid]), epoch_time_convertor(arr[mid + 1]), target) == 0:
            return mid
        else:
            return mid+1


# findClosest
# We find the closest by taking the difference
# between the target and both values. It assumes
# that val2 is greater than val1 and target lies
# between these two. 
#return 0 means val1 is closer, return 1 means val2 is closer
def find_closest(val1, val2, target):
    return 1 if target - val1 >= val2 - target else 0



def lambda_handler(event, context):
        
    bucket_name = event["bucket"]
    s3_file_name = event["key"]
    timestamp = event['timestamp']
    interval = event['interaval']
    pattern = re.compile(event['pattern'])
    
    try:
        data = s3_cient.get_object(Bucket=bucket_name, Key=s3_file_name)
        log_data = data['Body'].read().decode('utf-8')
        
        df = pd.read_csv(StringIO(log_data),sep = " ",header=None,error_bad_lines=False,usecols=[0,6])
        #print (df)

        df[6] = df[6].astype(str)

        timestamp_list = df[0].values.tolist()
        log_string_list = df[6].values.tolist()
        high = len(timestamp_list) - 1
        low = 0
                
        #check if time + interval exceeds last element or is lesser than first, find all message till the start and end time

        if (epoch_time_convertor(timestamp) > epoch_time_convertor(df[0].tail(1).item())) or (epoch_time_convertor(timestamp) < epoch_time_convertor(df[0].head(1).item())):
            message = "The timestamp is not present in the log file"
            print(message)
            code = 400
            
        else:
            index_of_timestamp = binary_search(timestamp_list,timestamp,low,high)
            lower_timestamp = epoch_time_convertor(timestamp) + pd.Timedelta(interval).seconds
            upper_timestamp = epoch_time_convertor(timestamp) - pd.Timedelta(interval).seconds
            
            upper_list = timestamp_list[:index_of_timestamp]
            lower_list = timestamp_list[index_of_timestamp:]
            
            #find closest index to upper interval
            upper_index = get_closest_index(upper_list,upper_timestamp)

            print("up",upper_index)
            #find closest index to lower interval
            lower_index = get_closest_index(lower_list,lower_timestamp)
            print("low",lower_index)

            matched_list = []

            if (lower_index < upper_index):
                matched_list = list(filter(pattern.findall, log_string_list[lower_index:upper_index]))

            else:
                matched_list = list(filter(pattern.findall, log_string_list[upper_index:lower_index]))

            if matched_list:
                message = hashlib.md5(matched_list[0].encode('utf-8')).hexdigest()
                print (message)
                code = 200
            else:
                message = "No matching pattern found"
                code = 404
            
        return{
            "response_code" : code,
            "data" : message
        }

    except Exception as e:
        print(e)
        raise e
